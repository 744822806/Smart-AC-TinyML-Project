import numpy as np
import pandas as pd

samples = 100000
temp = np.random.uniform(0, 45, samples)
light = np.random.uniform(0, 100, samples)
humid = np.random.uniform(0, 100, samples)

ac_on = (light > 70) & ((temp > 25) | (humid > 65))
labels = ac_on.astype(int)

df = pd.DataFrame({'temperature': temp, 'light': light, 'humidity': humid, 'ac_on': labels})
df.to_csv('sample_data.csv', index=False)
print('✅ Dataset saved: sample_data.csv')
