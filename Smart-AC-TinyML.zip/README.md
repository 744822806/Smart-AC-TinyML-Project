# 🤖 Smart Air Conditioner (AC) Controller using TinyML and TensorFlow

**Course:** TELE 6550 - Intro to IoT Smart/Embedded Device Development  
**Author:** Heyang (Henry) Liu  

This project combines **AI + IoT + TinyML**: an Artificial Neural Network trained in TensorFlow predicts when an AC should turn on based on temperature, light, and humidity, then runs inference on an ESP32 microcontroller.

---

## 🌍 Overview
- Temperature: 0–45°C
- Light Intensity: 0–100%
- Humidity: 0–100%
- If (light > 70%) and (temperature > 25°C or humidity > 65%) → AC ON.

---

## 🧠 Workflow
1. Generate 100k-sample dataset (`data/dataset_generator.py`)
2. Train ANN with TensorFlow (`model/train_ann_model.ipynb`)
3. Convert to TinyML model (.tflite)
4. Run on ESP32 (`esp32/main.c` + `esp32/predict.c`)

---

## 📈 ANN Structure
- Input: 3 neurons (Temp, Light, Humid)
- Hidden: 8 neurons, ReLU activation
- Output: 1 neuron, Sigmoid
- Optimizer: Adam  
- Loss: Binary Crossentropy

---

## ⚙️ ESP32 Code Example
```c
bool predict(int temperature, int light, int humidity) {
    if (light > 70 && (temperature > 25 || humidity > 65))
        return true;
    return false;
}
```

---

## 🧩 Console Output Example
```
Smart AC Predictor Demo
Temp:29°C Light:84% Hum:32% => AC: ON
Temp:22°C Light:68% Hum:45% => AC: OFF
Temp:28°C Light:92% Hum:70% => AC: ON
```
---

## 🚀 Future Work
- Integrate actual TinyML model inference on ESP32.
- Add DHT11/BH1750 sensor readings.
- Display results on OLED or via MQTT dashboard.
- Implement OTA updates.
