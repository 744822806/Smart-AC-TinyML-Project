#include <stdbool.h>

bool predict(int temperature, int light, int humidity) {
    if (light > 70 && (temperature > 25 || humidity > 65))
        return true;
    return false;
}
