#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "predict.c"

void app_main() {
    printf("Smart AC Predictor Demo\n");
    for (int i = 0; i < 50; i++) {
        int temp = rand() % 46;
        int light = rand() % 101;
        int humid = rand() % 101;
        bool ac = predict(temp, light, humid);
        printf("Temp:%d°C Light:%d%% Hum:%d%% => AC: %s\n", temp, light, humid, ac ? "ON" : "OFF");
    }
}
